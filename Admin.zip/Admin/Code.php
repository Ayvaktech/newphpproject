<?php
include 'connection.php';
ob_start();

if(isset($_POST['id']))
{
    $id = $_POST['id'];
    $q = "SELECT * FROM `user_reg` WHERE id = '$id'";
    $query = mysqli_query($con,$q);
    $row = mysqli_fetch_array($query);
    echo json_encode($row);    
}

if(isset($_POST['empid']))
{
    $id = $_POST['empid'];
    $q = "SELECT * FROM `emp_reg` WHERE emp_id = '$id'";
    $query = mysqli_query($con,$q);
    $row = mysqli_fetch_array($query);
    echo json_encode($row);    
}



if(isset($_POST['freeid']))
{
    $id = $_POST['freeid'];
    //$q = "SELECT * FROM `freelance_register` WHERE ID='$id' ";
    $q = "SELECT d.ImageUrl,r.Full_name,r.Email,r.register_with,d.FreProfile,d.Experience,d.Frestatus,d.Age,d.location FROM `freelance_register` as r INNER JOIN freelancer_details as d on r.ID = d.ID
WHERE  r.ID='$id'";
    $query = mysqli_query($con,$q);
    $row = mysqli_fetch_array($query);
    echo json_encode($row); 
}




?>