<nav class="navbar navbar-default navbar-fixed navbar-light white bootsnav">

				<div class="container">            
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
						<i class="fa fa-bars"></i>
					</button>
					<!-- Start Header Navigation -->
					<div class="navbar-header">
						<a class="navbar-brand" href="index.php">
							<img src="assets/img/logo/log.png" class="logo logo-scrolled" alt="">
						</a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="navbar-menu">
			<ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
							
							<li class="dropdown "><a href="#" class="dropdown-toggle" data-toggle="dropdown">Dashboard</a>
								<ul class="dropdown-menu megamenu-content" role="menu">
									<li>
										<div class="row">
										<!-- end col-3 -->
										<!-- end col-3 -->
											<div class="col-menu col-md-12">
												<h6 class="title">For Employer</h6>
												<div class="content">
													<ul class="menu-col">
														<li><a href="create-job.php">Post a Job</a></li>
                                                <li><a href="create-company.php">Create Company</a></li>
                                                 <li><a href="blogcreate.php">Create Blog</a></li>
                                                <li><a href="manage-company.php">Manage Company</a></li>
                                                <li><a href="manage-candidate.php">Manage Candidate</a></li> 
                                                 <li><a href="employer-profile.php">Employer Profile</a></li>                                            
                                               
                                               
                                               
                                                
													</ul>
												</div>
											</div>    
											<!-- end col-3 -->
										</div><!-- end row -->
									</li>
								</ul>
							</li>
							
						</ul>
						<ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">

                   <li><a href="logout.php">Logout</a></li>                </ul>

						</ul>
					</div><!-- /.navbar-collapse -->
				</div>   
			</nav>