
<!DOCTYPE html>






<html lang="en-GB" id="oracle-cc" data-bind="setContextVariable:{name:'masterViewModel', value:$data}" dir="ltr">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta charset="utf-8">
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- CSS==================================================-->
    <link rel="stylesheet" href="assets/plugins/css/plugins.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="assets/css/style.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" id="jssDefault" href="assets/css/colors/green-style.css">
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script type="text/javascript" src="script.js"></script>
    <script type="text/javascript" src="script1.js"></script>
    <script type="text/javascript" src="script2.js"></script>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

  
  
 
  <!-- /ko -->
  <!-- /ko -->

  
  
  
  <script type="text/javascript">
      function getSamlResponse() {
        return "";
      }
  </script>
  <script type="text/javascript">
      function getAgentAuthToken() {
        return "";
     }
  </script>
  <script type="text/javascript">
      function getAgentRedirectUrl() {
        return "";
     }
  </script>
  <script type="text/javascript">    
        function getRelayState() {
          return "";
        }
  </script>      
  <script type="text/javascript">
      function getOAuthToken() {
        return "";
     }
      function getAdditionalFormData() {
        var additionalFormDataJson = {  
            
        };
        return additionalFormDataJson;
     }
  </script>
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<noscript>
</noscript>

<style type="text/css">
  body {
    padding-top: 50px;
  padding-bottom: 50px;
}

.price-box {
  margin: 0 auto;
  background: #E9E9E9;
  border-radius: 3px;
  padding: 00px 15px;
  width: 500px;
}

.ui-widget-content {
  border: 1px solid #bdc3c7;
  background: #e1e1e1;
  color: #222222;
  margin-top: 4px;
}

.ui-slider .ui-slider-handle {
  position: absolute !important;
  z-index: 2 !important;
  width: 3.2em !important;
  height: 2.2em !important;
  cursor: default !important;
  margin: 0 -20px auto !important;
  text-align: center !important;  
  line-height: 30px !important;
  color: #FFFFFF !important;
  font-size: 15px !important;
}

.ui-corner-all {
  /*border-radius: 20px;*/
}

.ui-slider-horizontal .ui-slider-handle {
  top: -3em !important;
}

.ui-state-default,
.ui-widget-content .ui-state-default {
  background: #393a40 !important;
}

.ui-slider-horizontal .ui-slider-handle {
  margin-left: -0.5em !important;
}

.ui-slider .ui-slider-handle {
  cursor: pointer;
}

.ui-slider a,
.ui-slider a:focus {
  cursor: pointer;
  outline: none;
}

.price, .lead p {
  font-weight: 600;
  font-size: 32px;
  display: inline-block;
  line-height: 60px;
}

h4.great {
  background: #00ac98;
  margin: 0 0 55px -60px;
  padding: 7px 15px;
  color: #ffffff;
  font-size: 18px;
  font-weight: 600;
  border-radius: 5px;
  display: inline-block;
  -moz-box-shadow:    2px 4px 5px 0 #ccc;
    -webkit-box-shadow: 2px 4px 5px 0 #ccc;
    box-shadow:         2px 4px 5px 0 #ccc;
}

.price-slider {
  margin-bottom: 70px;
}

.form-pricing {
  background: #ffffff;
  padding: 20px;
  border-radius: 4px;
}

.price-form {
  background: #ffffff;
  margin-bottom: 10px;
  padding: 20px;
  border: 1px solid #eeeeee;
  border-radius: 4px;
}

.form-group {
  margin-bottom: 0;
}

.form-group span.price {
  font-weight: 200;
  display: inline-block;
  color: #7f8c8d;
  font-size: 14px;
}

.help-text {
  display: block;
  margin-top: 32px;
  margin-bottom: 10px;
  color: #737373;
  position: absolute;
  font-weight: 200;
  text-align: right;
  width: 188px;
}

.price-form label {
  font-weight: 200;
  font-size: 21px;
}

.ui-slider-range-min {
  background: #2980b9;
}

.ui-slider-label-inner {
    border-left: 10px solid transparent;
    border-right: 10px solid transparent;
    border-top: 10px solid #393a40;
    display: block;
    left: 50%;
    margin-left: -10px;
    position: absolute;
    top: 100%;
    z-index: 99;
}
@media (min-width: 992px)
.col-md-6 {
    width: 37%;
}
@media screen and (min-width: 992px) {
  .col-md-6 {
    width: 37%;
}
</style>
<body>
    <?php
    include('userheader.php');
    ?>

    
<div class="row" style="background-color:rgb(60, 60, 60);    padding-bottom: 10px;">
  <h1 class="w3-center w3-text-white">Job ad+</h1>
  <p class="w3-center w3-text-white">Use your company brand to attract the best candidates from totaljobs and Jobsite</p>
<div class="contaniner">
  <div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-4" style="background-color:lightgray;height:365px;">
      
      <ul style="    margin-top: 59px;"><li style="font-size: 23px;font-family: Montserrat,sans-serif;">One month to post your ad</li>
<li style="font-size: 23px;font-family: Montserrat,sans-serif;">Job ad live for six-weeks</li>
<li style="font-size: 23px;font-family: Montserrat,sans-serif;">Job ad sent directly to relevant candidates</li>
<li style="font-size: 23px;font-family: Montserrat,sans-serif;">Applicant management system to manage all candidates</li></ul>
    </div>
  
  <div class="col-md-6">
  
    <div class="price-box">
        <form class="form-horizontal form-pricing" role="form">
            <div class="price-slider">
                <h4 class="great">Amount</h4>

                <div class="col-sm-12">
                    <div id="slider"></div>
                </div>
            </div>
            <div class="price-form">
                <div class="form-group">
                    <label for="amount" class="col-xs-6 control-label">Amount ($): </label>
                    <span class="help-text">Please choose your amount</span>

                    <div class="col-xs-6 ">
                        <input type="hidden" id="amount" class="form-control">

                        <p class="price lead" id="amount-label"></p>
                        <span class="price">.00</span><br>
                          <button class="btn btn-info" type="submit" name="submit">Buy Now</button> 
                    </div>

                </div>
            </div>
        </form>
    
</div>
</div></div></div>
</div>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.10.4/jquery-ui.min.js"></script>

<div clsss="row" style="background-color: #f7f7f7;">
  <div class="col-md-12">
<h2 class="w3-center">Advertise a job today and benefit from</h2>
</div>
   <div class="row">
  <div class="col-md-3 col-md-offset-1">
     
     <center> <img src="https://recruiting.totaljobs.com/file/general/icn-map.svg" style="height:100px ">
      <h3 class="banner__card-text">Access to half of the UK’s working population</h3></center>
    </div>
  
  
<div class="col-md-3">
      <center><img src="https://recruiting.totaljobs.com/file/general/icn-sixweeks.svg" style="height:100px">
      <h3 class="banner__card-text">A six-week job posting on both totaljobs and Jobsite</h3></center>
    </div>
  
  <div class="col-md-3">

      <center><img src="https://recruiting.totaljobs.com/file/general/icn-stepmatch1.svg" style="height:100px">
    
      <h3 class="banner__card-text">One single system to manage candidates</h3></center>
    </div></div></div>

     
  
 

  <div class="row" style="margin-top:50px ">
    <div class="col-md-12">
  <h1 class="g-heading_pure brandFontReg w3-center" style="margin-top: 30px;margin-bottom:50px;">Three easy steps</h1>
</div>
  <div class="row" style="margin-top:50px ">
  <div class="col-md-3 col-md-offset-1 ">
    <div class="row">
      <div class="col-md-12">
     <center> <h3 class="g-heading_pure brandFont">Write your job ad</h3>
      
      <img src="https://recruiting.totaljobs.com/file/general/tj-icn-job-ad.svg" style="height:100px ">
      <p class="banner__card-text brandFont">Include your location, salary range, the experience and the key skills you need. This is also your chance to make your role and company stand out from the competition.</p></center>
      <div >
    </div>
  </div>
</div></div>
<div class="col-md-3">
  <div class="row">
  <div class="col-md-12">
   <center> <h3 class="g-heading_pure brandFont">Publish your job ad online</h3>
    <img src="https://recruiting.totaljobs.com/file/general/tj-icn-premium-job.svg"  style="height:100px ">
    <p class="banner__card-text brandFont">Once you're happy, your job ad will go live on our site and we’ll target relevant candidates for you. If your requirements change, your ad is completely editable for 6-weeks.</p></center>
    
    </div></div>
  
  </div>
  <div class="col-md-3">
    <div class="row">
      <div class="col-md-12">
       <center> <h3 class="g-heading_pure brandFont">Find your ideal candidate</h3>
        <img src="https://recruiting.totaljobs.com/file/general/tj-icn-cv-update.svg" style="height:100px ">
        <p class="banner__card-text brandFont">Candidates can apply immediately when your job ad goes live and you can manage your job applications, wherever you are, from any device with our applicant manager system.</p></center>
    </div></div>
    </div></div></div>


<div class="row" style="background-color: #f7f7f7;">
 <center><h1 style="margin-top:50px ">Some of the great companies using totaljobs</h1></center>
 <div class="container" style="margin-left:100px;margin-top:50px  ">
  <div class="col-md-3 ">
   <img alt="sky" class="banner__logo" src="https://recruiting.totaljobs.com/file/general/company1.png">
  </div>
  <div class="col-md-3">
   <img alt="sky" class="banner__logo" src="https://recruiting.totaljobs.com/file/general/company2.png">
  </div>
  <div class="col-md-3">
   <img alt="sky" class="banner__logo" src="https://recruiting.totaljobs.com/file/general/company3.png">
  </div>
  <div class="col-md-3">
   <img alt="sky" class="banner__logo" src="https://recruiting.totaljobs.com/file/general/company4.png">
  </div>
</div>
</div></div>


<?php
include('footer.php');
?>



<script type="text/javascript">
  $(document).ready(function () {
        $("#slider").slider({
            range: "min",
            animate: true,
            value: 1,
            min: 0,
            max: 1000,
            step: 10,
            slide: function (event, ui) {
                update(1, ui.value); //changed
            }
        });

        //Added, set initial value.
        $("#amount").val(0);
        $("#amount-label").text(0);


        update();
    });

    //changed. now with parameter
    function update(slider, val) {
        //changed. Now, directly take value from ui.value. if not set (initial, will use current value.)
        var $amount = slider == 1 ? val : $("#amount").val();

        /* commented
         $amount = $( "#slider" ).slider( "value" );
         $duration = $( "#slider2" ).slider( "value" );
         */

        $("#amount").val($amount);
        $("#amount-label").text($amount);

        $('#slider a').html('<label>' + $amount + '</label><div class="ui-slider-label-inner"></div>');
    }
</script>

















</body>
</html>