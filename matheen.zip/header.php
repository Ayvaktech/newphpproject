<nav class="navbar navbar-default navbar-fixed navbar-light white bootsnav">

				<div class="container">            
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
						<i class="fa fa-bars"></i>
					</button>
					<!-- Start Header Navigation -->
					<div class="navbar-header">
						<a class="navbar-brand" href="index.php">
							<img src="assets/img/logo/log.png" class="logo logo-scrolled" alt="">
						</a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="navbar-menu">
			<ul class="nav navbar-nav navbar-left" data-in="fadeInDown" data-out="fadeOutUp">
							
							<li class="dropdown "><a href="#" class="dropdown-toggle" data-toggle="dropdown">Dashboard</a>
								<ul class="dropdown-menu megamenu-content" role="menu">
									<li>
										<div class="row">
										<!-- end col-3 -->
											<div class="col-menu col-md-12">
												<h6 class="title">For Candidate</h6>
												<div class="content">
													<ul class="menu-col">
														<li><a href="browse-job.php">Browse Jobs</a></li>
                                                <li><a href="browse-company.php">Browse Companies</a></li>                       
                                                <li><a href="create-resume.php">Create Resume</a></li> 
                                                <li><a href="profile.php">Candidate Profile</a></li> 
                                                <!--<li><a href="job-grid.php">Job In Grid</a></li>-->
                                                <li><a href="browse-resume.php">Manage Resume </a></li>
													</ul>
												</div>
											</div><!-- end col-3 -->
											   
											<!-- end col-3 -->
										</div><!-- end row -->
									</li>
								</ul>
							</li>
							<li class="">
                        <a href="create-cv.php" class="dropdown-toggle" data-toggle="dropdown">Create Your CV</a>
                        
                    </li>
                    <li class="">
                        <a href="professional-cv.php" class="dropdown-toggle" data-toggle="dropdown">Professional Cv</a>
                        
                    </li>  
						</ul>
						<ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">

                   <li><a href="logout.php">Logout</a></li>                </ul>

						</ul>
					</div><!-- /.navbar-collapse -->
				</div>   
			</nav>