<?php
ob_start();
session_start();
?>


<!doctype html>
<html lang="en">

<!-- freelancer-detail41:45-->
<head>
	<!-- Basic Page Needs
	================================================== -->
	<title>Job </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- CSS
	================================================== -->
	<link rel="stylesheet" href="assets/plugins/css/plugins.css">
    
    <!-- Custom style -->
    <link href="assets/css/style.css" rel="stylesheet">
	<link type="text/css" rel="stylesheet" id="jssDefault" href="assets/css/colors/green-style.css">
    
	</head>
	<body>
		
		<div class="wrapper">  
			
			<!-- Start Navigation -->
			<?php
			include('header2.php');
			?>
			<!-- End Navigation -->
			<div class="clearfix"></div>
			
			<!-- Title Header Start -->
			<section class="inner-header-page">
				<div class="container">
				<?php
                    include 'connection.php';
                    
                 if(isset($_SESSION["id"]))
                 {
                 	$id  = $_SESSION["id"];
                 	 $q = "SELECT freelance_register.ID,freelance_register.Full_name,freelancer_details.ID,freelancer_details.FreProfile,freelancer_details.Experience,freelancer_details.Frestatus,freelancer_details.Age,freelancer_details.location,freelancer_details.description,freelancer_details.ImageUrl from freelancer_details,freelance_register WHERE freelance_register.ID='$id' AND freelancer_details.ID ='$id'";
                        $query = mysqli_query($con,$q);
                        $row = mysqli_fetch_array($query);
                 }  
                 else
                 {
                        header('location:new-login-signup.php');
                  }
                   
                    ?>
					
					<div class="col-md-8">
						<div class="left-side-container">
							<div class="freelance-image"><a href="company-detail.html"><img src="Freelance_Images/<?php echo $row['ImageUrl']; ?>" class="img-responsive img-circle" alt=""></a></div>
							<div class="header-details">
								<h4><?php echo $row['Full_name'];?><span class="pull-right">$44/hr</span></h4>
								<p><?php echo $row['FreProfile'] ?></p>
								<ul>
									<li><a href="http://themezhub.com/"><i class="fa fa-building"></i> Mack Star</a></li>
									<li>
										<div class="star-rating" data-rating="4.2">
											<span class="fa fa-star fill"></span>
											<span class="fa fa-star fill"></span>
											<span class="fa fa-star fill"></span>
											<span class="fa fa-star fill"></span>
											<span class="fa fa-star-half fill"></span>
										</div>
									</li>
									<li><img class="flag" src="assets/img/gb.svg" alt=""> <?php echo $row['location'] ?></li>
									<li><div class="verified-action">Verified</div></li>
								</ul>
							</div>
						</div>
					</div>
					
					<div class="col-md-4 bl-1 br-gary">
						<div class="right-side-detail">
							<ul>
								<li><span class="detail-info">Availability</span><?php echo $row['Frestatus']; ?><span class="available-status"><?php echo $row['Frestatus']; ?></span></li>
								<li><span class="detail-info">Location</span><?php echo $row['location']; ?></li>
								<li><span class="detail-info">Experience</span><?php echo $row['Experience']; ?></li>
								<li><span class="detail-info">Age</span><?php echo $row['Age']; ?></li>
							</ul>
							<ul class="social-info">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
							</ul>
						</div>
					</div>
					
				</div>
			</section>
			<div class="clearfix"></div>
			<!-- Title Header End -->
			
			<!-- Freelancer Detail Start -->
			<section>
				<div class="container">
					
					<div class="col-md-8 col-sm-8">
						<div class="container-detail-box">
						
							<div class="apply-job-header">
								<h4><?php echo $row['Full_name']; ?></h4>
								<a href="company-detail.html" class="cl-success"><span><i class="fa fa-building"></i><?php echo $row['FreProfile']; ?></span></a>
								<span><i class="fa fa-map-marker"></i><?php echo $row['location']; ?></span>
							</div>
							
							<div class="apply-job-detail">
								<p><?php echo $row['description']; ?></p>
								
							</div>
							
							<div class="apply-job-detail">
								<h5>Skills</h5>
								<ul class="skills">
									<li>Css3</li>
									<li>Html5</li>
									<li>Photoshop</li>
									<li>Wordpress</li>
									<li>PHP</li>
									<li>Java Script</li>
								</ul>
							</div>
							
							<div class="apply-job-detail">
								<h5>Language</h5>
								<ul class="language">
									<li><img class="flag" src="assets/img/gb.svg" alt="">English</li>
									<li><img class="flag" src="assets/img/gb.svg" alt="">French</li>
									<li><img class="flag" src="assets/img/gb.svg" alt="">Hindi</li>
								</ul>
							</div>
							
							<a href="#" class="btn btn-success">Make An Offer</a>
							
						</div>
						
						<!-- Similar Jobs -->
						
					</div>
					
					<!-- Sidebar Start-->
					<div class="col-md-4 col-sm-4">
						
						<!-- Make An Offer -->
						<div class="sidebar-container">
							<div class="sidebar-box">
								<span class="sidebar-status"><?php echo $row['Frestatus']; ?></span>
								<h4 class="flc-rate">$17/hr</h4>
								<div class="sidebar-inner-box">
									<div class="sidebar-box-thumb">
										<img src="Freelance_Images/<?php echo $row['ImageUrl']; ?>" class="img-responsive img-circle" alt="" />
									</div>
									<div class="sidebar-box-detail">
										<h4><?php echo $row['FreProfile']; ?></h4>
										<span class="desination"><?php echo $row['FreProfile']; ?></span>
									</div>
								</div>
								<div class="sidebar-box-extra">
									<ul>
										<li>Php</li>
										<li>Android</li>
										<li>Html</li>
										<li class="more-skill bg-primary">+3</li>
									</ul>
									<ul class="status-detail">
										<li class="br-1"><strong>$44/hr</strong>Hourly Rate</li>
										<li class="br-1"><strong>52 Jobs</strong>Done job</li>
										<li><strong>44</strong>Rehired</li>
									</ul>
								</div>
							</div>
							<a href="http://themezhub.com/" class="btn btn-sidebar bt-1 bg-success">Make An Offer</a>
						</div>
						
						<!-- Website & Portfolio -->
						<!--<div class="sidebar-wrapper">
							<div class="sidebar-box-header bb-1">
								<h4>Website & Portfolio</h4>
							</div>
						
							<ul class="block-list">
								<li><i class="fa fa-globe cl-success"></i>www.mysite.com</li>
								<li><i class="fa fa-briefcase cl-success"></i>Portfolio</li>
								<li><i class="fa fa-pencil cl-success"></i>My Blog</li>
							</ul>
						</div>
						
						<!-- Similar Profile -->
						<!--<div class="sidebar-wrapper">
						
							<div class="sidebar-box-header bb-1">
								<h4>Similar Profiles</h4>
							</div>
						
							<div class="member-profile-list">
								<div class="member-profile-thumb">
									<a href="company-detail.html"><img src="assets/img/can-2.png" class="img-responsive img-circle" alt="" /></a>
								</div>
								<div class="member-profile-detail">
									<h4><a href="company-detail.html">Adam Crivatinly</a></h4>
									<span>Web Developer</span>
									<span class="cl-success">Freelancer</span>
								</div>
							</div>
							
							<div class="member-profile-list">
								<div class="member-profile-thumb">
									<a href="company-detail.html"><img src="assets/img/can-3.png" class="img-responsive img-circle" alt="" /></a>
								</div>
								<div class="member-profile-detail">
									<h4><a href="company-detail.html">Adam Crivatinly</a></h4>
									<span>Web Developer</span>
									<a href="company-detail.html"><span class="cl-success">Freelancer</span></a>
								</div>
							</div>
							
							<div class="member-profile-list">
								<div class="member-profile-thumb">
									<a href="company-detail.html"><img src="assets/img/can-4.png" class="img-responsive img-circle" alt="" /></a>
								</div>
								<div class="member-profile-detail">
									<h4><a href="company-detail.html">Adam Crivatinly</a></h4>
									<span>Web Developer</span>
									<a href="company-detail.html"><span class="cl-success">Freelancer</span></a>
								</div>
							</div>
							
						</div>
						
						<!-- Share This Job -->
						<!--<div class="sidebar-wrapper">
							<div class="sidebar-box-header bb-1">
								<h4>Share This Job</h4>
							</div>
						
							<ul class="social-share">
								<li><a href="#" class="fb-share"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" class="tw-share"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" class="gp-share"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#" class="in-share"><i class="fa fa-instagram"></i></a></li>
								<li><a href="#" class="li-share"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#" class="be-share"><i class="fa fa-behance"></i></a></li>
							</ul>
						</div>-->
						
					</div>
					<!-- End Sidebar -->
					
				</div>
			</section>
			<!-- Freelancer Detail End -->
			
			<!-- Footer Section Start -->
			<?php
			include('footer.php');
			?>
			<div class="clearfix"></div>
			<!-- Footer Section End -->
			
			<!-- Sign Up Window Code -->
			<div class="modal fade" id="signup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-body">
							<div class="tab" role="tabpanel">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation" class="active"><a href="#login" role="tab" data-toggle="tab">Sign In</a></li>
								<li role="presentation"><a href="#register" role="tab" data-toggle="tab">Sign Up</a></li>
							</ul>
							<!-- Tab panes -->
							<div class="tab-content" id="myModalLabel2">
								<div role="tabpanel" class="tab-pane fade in active" id="login">
									<img src="assets/img/logo.png" class="img-responsive" alt="" />
									<div class="subscribe wow fadeInUp">
										<form class="form-inline" method="post">
											<div class="col-sm-12">
												<div class="form-group">
													<input type="email"  name="email" class="form-control" placeholder="Username" required="">
													<input type="password" name="password" class="form-control"  placeholder="Password" required="">
													<div class="center">
													<button type="submit" id="login-btn" class="submit-btn"> Login </button>
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>

								<div role="tabpanel" class="tab-pane fade" id="register">
								<img src="assets/img/logo.png" class="img-responsive" alt="" />
									<form class="form-inline" method="post">
											<div class="col-sm-12">
												<div class="form-group">
													<input type="text"  name="email" class="form-control" placeholder="Your Name" required="">
													<input type="email"  name="email" class="form-control" placeholder="Your Email" required="">
													<input type="email"  name="email" class="form-control" placeholder="Username" required="">
													<input type="password" name="password" class="form-control"  placeholder="Password" required="">
													<div class="center">
													<button type="submit" id="subscribe" class="submit-btn"> Create Account </button>
													</div>
												</div>
											</div>
										</form>
								</div>
							</div>
							</div>
						</div>
						</div>
				</div>
			</div>   
			<!-- End Sign Up Window -->
			<button class="w3-button w3-teal w3-xlarge w3-right" onclick="openRightMenu()"><i class="spin fa fa-cog" aria-hidden="true"></i></button>
			<div class="w3-sidebar w3-bar-block w3-card-2 w3-animate-right" style="display:none;right:0;" id="rightMenu">
				<button onclick="closeRightMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button>
				<ul id="styleOptions" title="switch styling">
					<li>
						<a href="javascript: void(0)" class="cl-box blue" data-theme="colors/blue-style"></a>
					</li>
					<li>
						<a href="javascript: void(0)" class="cl-box red" data-theme="colors/red-style"></a>
					</li>
					<li>
						<a href="javascript: void(0)" class="cl-box purple" data-theme="colors/purple-style"></a>
					</li>
					<li>
						<a href="javascript: void(0)" class="cl-box green" data-theme="colors/green-style"></a>
					</li>
					<li>
						<a href="javascript: void(0)" class="cl-box dark-red" data-theme="colors/dark-red-style"></a>
					</li>
					<li>
						<a href="javascript: void(0)" class="cl-box orange" data-theme="colors/orange-style"></a>
					</li>
					<li>
						<a href="javascript: void(0)" class="cl-box sea-blue" data-theme="colors/sea-blue-style "></a>
					</li>
					<li>
						<a href="javascript: void(0)" class="cl-box pink" data-theme="colors/pink-style"></a>
					</li>
				</ul>
			</div>
			
			<!-- Scripts
			================================================== -->
			<script type="text/javascript" src="assets/plugins/js/jquery.min.js"></script>
			<script type="text/javascript" src="assets/plugins/js/viewportchecker.js"></script>
			<script type="text/javascript" src="assets/plugins/js/bootstrap.min.js"></script>
			<script type="text/javascript" src="assets/plugins/js/bootsnav.js"></script>
			<script type="text/javascript" src="assets/plugins/js/select2.min.js"></script>
			<script type="text/javascript" src="assets/plugins/js/wysihtml5-0.3.0.js"></script>
			<script type="text/javascript" src="assets/plugins/js/bootstrap-wysihtml5.js"></script>
			<script type="text/javascript" src="assets/plugins/js/datedropper.min.js"></script>
			<script type="text/javascript" src="assets/plugins/js/dropzone.js"></script>
			<script type="text/javascript" src="assets/plugins/js/loader.js"></script>
			<script type="text/javascript" src="assets/plugins/js/owl.carousel.min.js"></script>
			<script type="text/javascript" src="assets/plugins/js/slick.min.js"></script>
			<script type="text/javascript" src="assets/plugins/js/gmap3.min.js"></script>
			<script type="text/javascript" src="assets/plugins/js/jquery.easy-autocomplete.min.js"></script>
			<!-- Custom Js -->
			<script src="assets/js/custom.js"></script>
			<script src="assets/js/jQuery.style.switcher.js"></script>
			<script type="text/javascript">
				$(document).ready(function() {
					$('#styleOptions').styleSwitcher();
				});
			</script>
			<script>
				function openRightMenu() {
					document.getElementById("rightMenu").style.display = "block";
				}

				function closeRightMenu() {
					document.getElementById("rightMenu").style.display = "none";
				}
			</script>
		</div>
	</body>

<!-- freelancer-detail41:47-->
</html>