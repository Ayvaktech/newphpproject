<footer class="footer">
        <div class="row lg-menu">
            <div class="container">
                <div class="col-md-4 col-sm-4"><img src="assets/img/logo/log.png" class="img-responsive" alt=""/>
                </div>
                
            </div>
        </div>
        <div class="row no-padding">
            <div class="container">
                <div class="col-md-3 col-sm-12">
                    <div class="footer-widget">
                        <h3 class="widgettitle widget-title">About Saraswathi Chandra</h3>

                        <div class="textwidget">
                            <p align="justify">Sarswatichandraglobal is the most innovative and second largest online job portal in India. 
                            The popularity of the portal is evident from the fact that it has crossed the more 
                            candidate landmark and has more than Thousands latest job vacancies from leading companies 
                            on the site</p>
                          
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <div class="footer-widget">
                        <h3 class="widgettitle widget-title">Quick Links</h3>

                        <div class="textwidget">
                            <div class="textwidget">
                                <ul class="footer-navigation">
                                    <li><a href="about-us.php" title="">About Us</a></li>
                                    <li><a href="blog.php" title="">Blog</a></li>
                                    <li><a href="services.php" title="">Terms of Service</a></li>
                                    <li><a href="privacy-policy.php" title="">Privacy Policy</a></li>
                                    <li><a href="register.php" title="">Register</a></li>
                                    <li><a href="contact-us.php" title="">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <div class="footer-widget">
                        <h3 class="widgettitle widget-title">Jobs In India</h3>

                        <div class="textwidget">
                            <ul class="footer-navigation">
                                <li><a href="#" title="">New Delhi</a></li>
                                <li><a href="#" title="">Mumbai</a></li>
                                <li><a href="#" title="">Noida</a></li>
                                <li><a href="#" title="">Gurugram</a></li>
                                <li><a href="#" title="">Kolkata</a></li>
                                <li><a href="#" title="">Bangalore</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                  <div class="col-md-3 col-sm-4">
                    <div class="footer-widget">
                        <h3 class="widgettitle widget-title">Jobs By Categories</h3>

                        <div class="textwidget">
                            <ul class="footer-navigation">
                                <li><a href="#" title="">Computer Software Job</a></li>
                                <li><a href="#" title="">Customer Service Jobs</a></li>
                                <li><a href="#" title="">Education Jobs</a></li>
                                <li><a href="#" title="">Engineering Jobs</a></li>
                                <li><a href="#" title="">Web & E-Commerce Jobs</a></li>
                                <li><a href="#" title="">Accounting Jobs</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row copyright">
            <div class="container">
                <p></p>
            </div>
        </div>
    </footer>